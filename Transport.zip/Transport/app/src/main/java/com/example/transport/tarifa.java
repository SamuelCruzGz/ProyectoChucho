package com.example.transport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tarifa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarifa);
    }
}